import { Router } from 'express'
import type { Request, Response } from 'express'
import { v4 as uuidv4 } from 'uuid'
import { generateToken, authMiddleware, type AuthRequest } from '../middleware/auth.js'
import { getUserByEmail, createUser } from '../services/userService.js'
import { success, error } from '../utils/response.js'
import { validate, loginSchema } from '../utils/validator.js'
import db from '../db.js'

const router = Router()

function generateCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

router.post('/send-code', (req: Request, res: Response): void => {
  const { email } = req.body
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    error(res, 'Invalid email', 400)
    return
  }

  const code = generateCode()
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()

  const stmt = db.prepare(
    'INSERT OR REPLACE INTO verify_codes (email, code, expires_at) VALUES (?, ?, ?)'
  )
  stmt.run(email, code, expiresAt)

  success(res, { message: 'Verification code sent' })
})

router.post('/login', (req: Request, res: Response): void => {
  const validation = validate(loginSchema, req.body)
  if (!validation.success) {
    error(res, validation.error, 400)
    return
  }

  const { email, code } = validation.data

  const record = db.prepare('SELECT * FROM verify_codes WHERE email = ?').get(email) as
    | { code: string; expires_at: string }
    | undefined

  if (!record) {
    error(res, 'Code not found', 400)
    return
  }

  if (record.code !== code) {
    error(res, 'Invalid code', 400)
    return
  }

  if (new Date(record.expires_at) < new Date()) {
    error(res, 'Code expired', 400)
    return
  }

  db.prepare('DELETE FROM verify_codes WHERE email = ?').run(email)

  let user = getUserByEmail(email)

  if (!user) {
    user = createUser(email, email.split('@')[0], `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`)
  }

  const token = generateToken({ id: user.id, email: user.email, nickname: user.nickname, avatar: user.avatar, isAdmin: user.isAdmin })

  success(res, {
    token,
    user: {
      id: user.id,
      email: user.email,
      nickname: user.nickname,
      avatar: user.avatar,
      credits: user.credits,
      isMember: user.isMember,
      isAdmin: user.isAdmin,
    },
  })
})

router.get('/me', authMiddleware, (req: AuthRequest, res: Response): void => {
  const user = getUserById(req.user!.id)

  if (!user) {
    error(res, 'User not found', 404)
    return
  }

  success(res, {
    user: {
      id: user.id,
      email: user.email,
      nickname: user.nickname,
      avatar: user.avatar,
      credits: user.credits,
      isMember: user.isMember,
      isAdmin: user.isAdmin,
    },
  })
})

function getUserById(userId: number) {
  return getUserByEmail(
    (db.prepare('SELECT email FROM users WHERE id = ?').get(userId) as { email: string } | undefined)?.email || ''
  )
}

export default router
